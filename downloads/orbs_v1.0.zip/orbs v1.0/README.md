Orbs v1.0
-----

**Overview**

Orbs is a midi visualiser desgined to be used with any usb or virutal midi instrument. Orbs can visualise up to 8 midi channels or 12 pitch values (depending on channel mode). Channels 13-15 are used for control. Each channel has it's own cell in a 4x2 (or 6x2) grid, with it's own colour. 

**Modes**

- Traditional: Ideal for multi-channel setups such as Orca or setups with numerous midi devices.
- Single Channel: Ideal for setups with a single device like a midi keyboard.

**How to Use**

You can use the software without any need for setup, as long as there is one midi device connected or avaliable on the computer. However further changes can be made through the use of the gui or midi commands.

Press 'd' to access GUI.

- GUI
	- Single Channel Mode: this toggle allows you to switch between single channel (pitch) or multi-channel (channel number) to influence the groups of orbs. 
	- Scatter: this toggle makes all of the orbs appear in random positions (not tied to their cell)
	- Random Cells: this toggle re-orders the cells 
	- Radomise: this button creates a new random order for the random cells
	- Drop down menu: allows you to select your midi device

- Midi Commands
	- Sending a midi message on channels 1-8 (1-12 in single channel mode) will generate an orb in the associated cell
	- Sending a midi message on channel 13 will trigger the randomise button
	- Sending a midi message on channel 14 will trigger the random cells toggle
	- Sending a midi message on channel 15 will trigger the scatter toggle

**_Make sure the contents of the folder stay in the main folder_**
	
**Videos**

- [Demonstration](https://vimeo.com/426269798)

**Made with**

- [openFrameworks] (https://openframeworks.cc/)
- [ofxMidi](https://github.com/danomatika/ofxMidi)
- [ofxDatGui](https://github.com/braitsch/ofxDatGui)

_Thanks to everyone who developed openFrameworks, the ofxMidi and ofxDatGui addon._